#include <stdio.h>
#include "generator.h"

int main (int argc, char ** argv)
{
/*
	boolean b1;

	printf !b1;
	printf !!b1;
*/

	FILE * salida;
	int num_nots = 0;

	if (argc != 2) {fprintf (stdout, "ERROR POCOS ARGUMENTOS\n"); return -1;}
	

	salida = fopen(argv[1],"w");

	escribir_subseccion_data(salida);
	escribir_cabecera_bss(salida);
	declarar_variable(salida, "b1", BOOLEANO, 1);


	escribir_segmento_codigo(salida);
	escribir_inicio_main(salida);

	leer(salida,"b1",BOOLEANO);
	escribir_operando(salida,"b1",1); 

	no(salida,1,num_nots++);
	escribir(salida,0,BOOLEANO);


	escribir_operando(salida,"b1",1);
	no(salida,1,num_nots++);
	no(salida,0,num_nots++);
	escribir(salida,0,BOOLEANO);

	escribir_fin(salida);

	fclose(salida);
	return 0;


}
